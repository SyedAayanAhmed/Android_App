import 'dart:async';
import 'dart:isolate';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:geolocator/geolocator.dart';

// Callback function that will be called by the foreground task
@pragma('vm:entry-point')
void startCallback() {
  // The port is used to communicate with the main isolate
  FlutterForegroundTask.setTaskHandler(TrackingTaskHandler());
}

// Task handler class that handles background location tracking
class TrackingTaskHandler extends TaskHandler {
  SendPort? _sendPort;
  Timer? _timer;

  // Called when the task is started
  @override
  void onStart(DateTime timestamp, SendPort? sendPort) {
    _sendPort = sendPort;

    // Start periodic location updates
    _timer = Timer.periodic(const Duration(seconds: 5), (timer) {
      _getCurrentLocation();
    });
  }

  // Called when the task is destroyed
  @override
  void onDestroy(DateTime timestamp, SendPort? sendPort) {
    _timer?.cancel();
  }

  // Called when the task receives a signal from the main isolate
  @override
  void onRepeatEvent(DateTime timestamp, SendPort? sendPort) {
    // You can also receive data from the main isolate
  }

  // Button event handler
  @override
  void onButtonPressed(String id) {
    if (id == 'stopButton') {
      // User pressed stop button in notification
      FlutterForegroundTask.stopService();
    }
  }

  // Get the current location and send it to the main isolate
  Future<void> _getCurrentLocation() async {
    try {
      final Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best,
      );

      // Send the position to the main isolate
      _sendPort?.send({
        'latitude': position.latitude,
        'longitude': position.longitude,
        'altitude': position.altitude,
        'timestamp': DateTime.now().millisecondsSinceEpoch,
      });
    } catch (e) {
      _sendPort?.send({'error': e.toString()});
    }
  }
}

class BackgroundTrackingService {
  static const String _portName = 'tracking_port';
  static ReceivePort? _receivePort;

  // Initialize the foreground task configuration
  static Future<void> initForegroundTask() async {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
        channelId: 'tracking_channel',
        channelName: 'TrackIN Foreground Service',
        channelDescription: 'Enables background location tracking',
        channelImportance: NotificationChannelImportance.LOW,
        priority: NotificationPriority.LOW,
        iconData: const NotificationIconData(
          resType: ResourceType.mipmap,
          resPrefix: ResourcePrefix.ic,
          name: 'launcher',
        ),
        buttons: [
          const NotificationButton(id: 'stopButton', text: 'Stop Tracking'),
        ],
      ),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: true,
        playSound: false,
      ),
      foregroundTaskOptions: const ForegroundTaskOptions(
        interval: 1000, // 1 second (minimum interval)
        isOnceEvent: false,
        autoRunOnBoot: false,
        allowWakeLock: true,
        allowWifiLock: false,
      ),
    );
  }

  // Start the foreground service with tracking
  static Future<bool> startTracking({
    required Function(Map<String, dynamic>) onLocationUpdate,
    required Function(String) onError,
  }) async {
    // Create a port for communication
    _receivePort = ReceivePort();

    // Register the port
    final registered = IsolateNameServer.registerPortWithName(
      _receivePort!.sendPort,
      _portName,
    );

    if (!registered) {
      IsolateNameServer.removePortNameMapping(_portName);
      IsolateNameServer.registerPortWithName(
        _receivePort!.sendPort,
        _portName,
      );
    }

    // Listen for messages from the service
    _receivePort!.listen((message) {
      if (message is Map<String, dynamic>) {
        if (message.containsKey('error')) {
          onError(message['error'] as String);
        } else {
          onLocationUpdate(message);
        }
      }
    });

    // Start the foreground service
    return await FlutterForegroundTask.startService(
      notificationTitle: 'TrackIN is running',
      notificationText: 'Tracking your location and altitude',
      callback: startCallback,
    );
  }

  // Stop the foreground service
  static Future<bool> stopTracking() async {
    // Clean up the port
    if (_receivePort != null) {
      _receivePort!.close();
      _receivePort = null;
    }

    // Remove the port name mapping
    IsolateNameServer.removePortNameMapping(_portName);

    // Stop the service
    return await FlutterForegroundTask.stopService();
  }

  // Check if the service is running
  static Future<bool> isTracking() async {
    return await FlutterForegroundTask.isRunningService;
  }
}
